//
//  main.m
//  MasonryTestsLoader
//
//  Created by Jonas Budelmann on 26/11/13.
//
//

#import <UIKit/UIKit.h>

#import "CASAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CASAppDelegate class]));
    }
}
